﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project7
{
    class Customer
    {
        public static string name
        {
            get; set;
        }

        public static string email
        {
            get; set;
        }

        public static int age
        {
            get; set;
        }

        public static string password
        {
            get; set;
        }
    }
}
